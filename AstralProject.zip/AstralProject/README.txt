Hello, I'm Astro_red And I'm The Founder Of This Script.
I Repeat that i have made this script only for fun, just don't abuse of this script.
I don't take any action you made with this script and the damage you can cause.
If you need help with something you can contact me on discord: luna_blitz.

